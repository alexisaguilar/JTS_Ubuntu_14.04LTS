#!/usr/bin/env python
# -*- coding: utf8 -*-

APACHE_PATH = "/etc/apache2/sites-available"
APACHE_RESTART_COMMAND = "service apache2 restart"