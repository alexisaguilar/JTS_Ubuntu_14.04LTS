#!/bin/bash
mkdir -p /srv/websites/$1/{application,logs,$2}